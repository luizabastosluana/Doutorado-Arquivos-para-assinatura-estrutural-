import os
import pandas as pd
import Signa.signa as signa # Certifique-se de que a biblioteca está instalada e importada corretamente
from tqdm import tqdm  # Importa a biblioteca tqdm para a barra de progresso

# Define o caminho da pasta com os arquivos PDB
pasta_pdb = '/home/triptofano/Transferências/interface/Interface_contato/' # Atualize este caminho para sua pasta

# Lista para armazenar os resultados
resultados = []

# Lista todos os arquivos na pasta
arquivos = [arquivo for arquivo in os.listdir(pasta_pdb) if arquivo.endswith('.pdb')]

# Usar tqdm para adicionar a barra de progresso
for arquivo in tqdm(arquivos, desc="Processando arquivos PDB"):
    # Remove o prefixo "interface_"
    id_interface = arquivo.replace('interface_', '').replace('.pdb', '')
    
    # Caminho completo do arquivo PDB
    caminho_completo = os.path.join(pasta_pdb, arquivo)
    
    # Calcula o ACSM usando a função signa.read
    acsm = signa.read(caminho_completo, 'acsm', cutoff_limit=10, cutoff_step=0.1, separator=",", cumulative=True)
    
    # Adiciona os resultados à lista
    resultados.append({'ID da Interface': id_interface, 'Vetor de Assinatura': acsm})

# Cria um DataFrame do pandas a partir dos resultados
df_resultados = pd.DataFrame(resultados)

# Salva o DataFrame em um arquivo CSV com tabulação e cabeçalho
caminho_csv = '/home/triptofano/Transferências/interface/Interface_contato/acsm_resultados.csv'  # Atualize este caminho conforme necessário
df_resultados.to_csv(caminho_csv, sep='\t', index=False, header=True)

print(f'Resultados salvos em {caminho_csv}')

